package org.eclipse.pde.internal.ui.preferences;

public class SourceCodeLocationsPreferenceNode extends TargetPlatformPreferenceNode {

	protected int getIndex() {
		return TargetPlatformPreferencePage.SOURCE_INDEX;
	}
}
