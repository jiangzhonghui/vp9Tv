package org.eclipse.pde.internal.ui.preferences;

public class TargetEnvironmentPreferenceNode extends TargetPlatformPreferenceNode {

	protected int getIndex() {
		return TargetPlatformPreferencePage.ENVIRONMENT_INDEX;
	}
}
